# Control Horario — Mi despertador nativo Android

Versión integrada del portal del empleado con alarmas locales de Android.

## Qué hace
- Abre el Portal del empleado de paperplegat.com.
- Incluye `Mi despertador` dentro de la app.
- 8 avisos por día: entrada, pausa 1, reanudar, comida, reanudar comida, pausa 2, reanudar pausa 2 y salida.
- Cada día de la semana se configura por separado.
- Las alarmas se programan en el propio Android con AlarmManager exacto.
- Funcionan con el portal cerrado y después de reiniciar el teléfono (se reprograman al arrancar).
- Botón de prueba inmediata.

## Primer uso
1. Instalar la APK.
2. Permitir notificaciones.
3. Si Android lo solicita, permitir "alarmas exactas".
4. Entrar en Mi despertador y guardar cada alarma.

## Compilación
Abrir la carpeta en Android Studio y generar `assembleDebug`.
También se incluye un workflow de GitHub Actions para compilar.
