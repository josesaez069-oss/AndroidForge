package com.controlhorario.despertador;
import android.content.*; public class BootReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){Scheduler.rescheduleAll(c);} }
