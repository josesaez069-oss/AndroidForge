package com.controlhorario.despertador;

import android.app.*;import android.os.*;import android.content.*;import android.net.Uri;import android.provider.Settings;import android.graphics.Color;import android.view.*;import android.webkit.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
 LinearLayout root, alarmList; Spinner daySpinner; SharedPreferences p; int day=Calendar.getInstance().get(Calendar.DAY_OF_WEEK); String portal="https://paperplegat.com/reloj/employee/index.php";
 String[] days={"Domingo","Lunes","Martes","Miércoles","Jueves","Viernes","Sábado"};
 @Override public void onCreate(Bundle b){super.onCreate(b); p=getSharedPreferences("alarms",0); if(Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},50); showHome();}
 TextView tv(String s,int z){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setPadding(20,18,20,18);return t;}
 Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextSize(15);return b;}
 void base(String title){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(16,16,16,16); TextView h=tv(title,26);h.setTextColor(Color.BLACK);root.addView(h);setContentView(root);}
 void showHome(){base("Control Horario"); TextView i=tv("Elige una opción",18);root.addView(i);Button portalBtn=btn("👤 Portal del empleado");portalBtn.setOnClickListener(v->showPortal());root.addView(portalBtn);Button alarm=btn("⏰ Mi despertador");alarm.setOnClickListener(v->showAlarms());root.addView(alarm);Button test=btn("🧪 Probar alarma ahora");test.setOnClickListener(v->testAlarm());root.addView(test);}
 void showPortal(){base("Portal del empleado"); WebView w=new WebView(this);w.getSettings().setJavaScriptEnabled(true);w.getSettings().setDomStorageEnabled(true);w.setWebViewClient(new WebViewClient());w.loadUrl(portal);root.addView(w,new LinearLayout.LayoutParams(-1,0,1));Button back=btn("← Volver");back.setOnClickListener(v->showHome());root.addView(back);}
 void showAlarms(){base("⏰ Mi despertador"); TextView info=tv("Las alarmas se ejecutan en este teléfono, incluso con el portal cerrado. Configura cada día.",16);root.addView(info);
  daySpinner=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,days);daySpinner.setAdapter(a);daySpinner.setSelection(day-1);daySpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?>x){} public void onItemSelected(android.widget.AdapterView<?>x,View v,int pos,long id){day=pos+1;renderSlots();}});root.addView(daySpinner);alarmList=new LinearLayout(this);alarmList.setOrientation(LinearLayout.VERTICAL);ScrollView sv=new ScrollView(this);sv.addView(alarmList);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));LinearLayout bar=new LinearLayout(this);Button test=btn("🧪 Probar");test.setOnClickListener(v->testAlarm());Button home=btn("← Inicio");home.setOnClickListener(v->showHome());bar.addView(test,new LinearLayout.LayoutParams(0,-2,1));bar.addView(home,new LinearLayout.LayoutParams(0,-2,1));root.addView(bar);renderSlots();}
 void renderSlots(){
  if(alarmList==null)return;
  alarmList.removeAllViews();
  for(int s=0;s<8;s++){
   final int slot=s;
   LinearLayout card=new LinearLayout(this);
   card.setOrientation(LinearLayout.VERTICAL);
   card.setPadding(10,10,10,14);
   card.setBackgroundColor(Color.rgb(245,247,250));
   LinearLayout.LayoutParams cardParams=new LinearLayout.LayoutParams(-1,-2);
   cardParams.setMargins(0,0,0,18);
   TextView label=tv(Scheduler.MSG[s],18);
   label.setTextColor(Color.rgb(25,45,65));
   card.addView(label,new LinearLayout.LayoutParams(-1,-2));

   TimePicker tp=new TimePicker(this);
   tp.setIs24HourView(true);
   tp.setMinute(p.getInt("d"+day+"s"+s+"m",0));
   tp.setHour(p.getInt("d"+day+"s"+s+"h",8+s));
   card.addView(tp,new LinearLayout.LayoutParams(-1,-2));

   LinearLayout actions=new LinearLayout(this);
   actions.setOrientation(LinearLayout.HORIZONTAL);
   actions.setGravity(Gravity.CENTER_VERTICAL);
   Switch sw=new Switch(this);
   sw.setText("Activar aviso");
   sw.setTextSize(15);
   sw.setChecked(p.getBoolean("d"+day+"s"+s,false));
   actions.addView(sw,new LinearLayout.LayoutParams(0,-2,1));
   Button save=btn("GUARDAR");
   save.setAllCaps(false);
   actions.addView(save,new LinearLayout.LayoutParams(0,-2,1));
   save.setOnClickListener(v->{
    String k="d"+day+"s"+slot;
    p.edit().putBoolean(k,sw.isChecked()).putInt(k+"h",tp.getHour()).putInt(k+"m",tp.getMinute()).apply();
    if(sw.isChecked()){
     if(Build.VERSION.SDK_INT>=31){
      AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
      if(!am.canScheduleExactAlarms()){
       startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));
       Toast.makeText(this,"Permite alarmas exactas y vuelve a GUARDAR",Toast.LENGTH_LONG).show();
       return;
      }
     }
     Scheduler.schedule(this,day,slot);
     Toast.makeText(this,"Aviso guardado para "+String.format(java.util.Locale.getDefault(),"%02d:%02d",tp.getHour(),tp.getMinute()),Toast.LENGTH_SHORT).show();
    }else{
     Scheduler.cancel(this,day,slot);
     Toast.makeText(this,"Aviso desactivado",Toast.LENGTH_SHORT).show();
    }
   });
   card.addView(actions,new LinearLayout.LayoutParams(-1,-2));
   alarmList.addView(card,cardParams);
  }
 }
 void testAlarm(){Intent i=new Intent(this,AlarmReceiver.class).putExtra("message","Recuerda fichar — prueba de alarma");sendBroadcast(i);Toast.makeText(this,"Aviso de prueba enviado",Toast.LENGTH_SHORT).show();}
}
