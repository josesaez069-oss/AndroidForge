package com.controlhorario.despertador;
import android.app.*;import android.content.*;import android.os.*;import java.util.*;
public class Scheduler {
 public static final String[] MSG={"Recuerda fichar la entrada","Recuerda fichar la pausa 1","Recuerda reanudar la pausa 1","Recuerda fichar la pausa de comida","Recuerda reanudar después de comer","Recuerda fichar la pausa 2","Recuerda reanudar la pausa 2","Recuerda fichar la salida"};
 static int id(int day,int slot){return day*100+slot;}
 public static void schedule(Context c,int day,int slot){
  android.content.SharedPreferences p=c.getSharedPreferences("alarms",0); if(!p.getBoolean("d"+day+"s"+slot,false)) return;
  int h=p.getInt("d"+day+"s"+slot+"h",9), m=p.getInt("d"+day+"s"+slot+"m",0); Calendar now=Calendar.getInstance(), t=Calendar.getInstance();
  t.set(Calendar.DAY_OF_WEEK,day); t.set(Calendar.HOUR_OF_DAY,h);t.set(Calendar.MINUTE,m);t.set(Calendar.SECOND,0);t.set(Calendar.MILLISECOND,0);
  if(!t.after(now)) t.add(Calendar.WEEK_OF_YEAR,1);
  Intent in=new Intent(c,AlarmReceiver.class).putExtra("message",MSG[slot]).putExtra("day",day).putExtra("slot",slot);
  PendingIntent pi=PendingIntent.getBroadcast(c,id(day,slot),in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
  if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) return;
  if(Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,t.getTimeInMillis(),pi); else am.setExact(AlarmManager.RTC_WAKEUP,t.getTimeInMillis(),pi);
 }
 public static void cancel(Context c,int day,int slot){AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);Intent in=new Intent(c,AlarmReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(c,id(day,slot),in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);am.cancel(pi);}
 public static void rescheduleAll(Context c){for(int d=Calendar.SUNDAY;d<=Calendar.SATURDAY;d++)for(int s=0;s<8;s++)schedule(c,d,s);}
}
