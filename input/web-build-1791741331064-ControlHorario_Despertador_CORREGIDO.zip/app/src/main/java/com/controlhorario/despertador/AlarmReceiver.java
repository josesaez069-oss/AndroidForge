package com.controlhorario.despertador;

import android.app.*;import android.content.*;import android.os.*;import java.util.*;

public class AlarmReceiver extends BroadcastReceiver {
 public static final String PREF="alarms";
 @Override public void onReceive(Context c, Intent i){
  String msg=i.getStringExtra("message"); int day=i.getIntExtra("day",0), slot=i.getIntExtra("slot",0);
  if(msg==null||msg.isEmpty()) msg="Recuerda fichar";
  NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE); String ch="fichaje";
  if(Build.VERSION.SDK_INT>=26){ NotificationChannel nc=new NotificationChannel(ch,"Recordatorios de fichaje",NotificationManager.IMPORTANCE_HIGH); nc.setDescription("Avisos de entrada, pausas y salida"); nm.createNotificationChannel(nc); }
  Intent open=new Intent(c,MainActivity.class).putExtra("tab","alarms"); PendingIntent pi=PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,ch):new Notification.Builder(c);
  b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("⏰ Control Horario").setContentText(msg).setStyle(new Notification.BigTextStyle().bigText(msg)).setContentIntent(pi).setAutoCancel(true).setVibrate(new long[]{0,700,300,700,300,1200}).setDefaults(Notification.DEFAULT_SOUND);
  nm.notify((int)(System.currentTimeMillis()%1000000),b.build());
  if(day>0) Scheduler.schedule(c,day,slot);
 }
}
